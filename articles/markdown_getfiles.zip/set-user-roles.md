---
lang: en-US
title: Setting Your User Role
description: How to set your user role
side: 'docs'
---


# Set Your User Roles

1. Sign in, entering your Jetnet username in the AA ID# field and your password in the Password field
2. Click Login
3. GET defaults to the home station

![Enter Credentials](./assets/img/rs20_l2p2.png)
![Role Selection](./assets/img/user-role.png)

*After login, GET asks for your role. This information will be used at a later date to grant correct access.*