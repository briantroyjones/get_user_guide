---
sidebar: 'docs'
---

# Installing GET

1. Open your browser and enter getng.aa.com
2. Download GET as an application on your desktop
3. Navigate to the Operations tab of the Toolbox section of airportal.aa.com
4. Select Ground event tracker from the list and select install.

![Toolbox](assets/img/toolbox_1.jpg)

![Toolbox](assets/img/toolbox2.jpg)

:::note
Contact your manager if you do not have the local permissions to install GET.
:::
5. Use this shortcut to launch GET in the future



![Stat Icons](assets/img/rs20_l3p11.png)

Beneath the Dashboard is the flight display section. There are three different views you can select from:

